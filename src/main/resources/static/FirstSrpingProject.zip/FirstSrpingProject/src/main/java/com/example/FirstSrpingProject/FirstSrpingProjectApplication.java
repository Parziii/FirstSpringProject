package com.example.FirstSrpingProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstSrpingProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstSrpingProjectApplication.class, args);
	}

}
