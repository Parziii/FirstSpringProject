package com.example.FirstSrpingProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSrpingProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
